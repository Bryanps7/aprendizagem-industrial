package com.Produto.modelBryan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModelBryanApplicationTests {

	@Test
	void contextLoads() {
	}

}
