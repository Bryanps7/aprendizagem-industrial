public class imcPessoa {
    private int id;
    private String nome;
    private int idade;
    private double peso;
    private double altura;

    public imcPessoa(){

    }

    public imcPessoa(int id, String nome, int idade, double peso, double altura) {
        this.id = id;
        this.nome = nome;
        this.idade = idade;
        this.peso = peso;
        this.altura = altura;
    }

    public double calcularImc(double peso, double altura) {
        return 0.0;
    }

    public String resultado(double imc) {
        return "arrumando ainda";
    }

    public double MDIdade(int idade) {
        return 0.0;
    }

    public double MDPeso(double peso) {
        return 0.0;
    }

    public double MDAltura(double altura) {
        return 0.0;
    }

    public String relatorioPessoa(String nome) {
        return "d";
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public double getPeso() {
        return peso;
    }

    public double getAltura() {
        return altura;
    }
}