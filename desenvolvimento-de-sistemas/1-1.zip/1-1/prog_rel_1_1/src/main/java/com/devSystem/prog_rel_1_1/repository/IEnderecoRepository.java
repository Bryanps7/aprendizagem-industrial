package com.devSystem.prog_rel_1_1.repository;

import com.devSystem.prog_rel_1_1.model.Endereco;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IEnderecoRepository extends JpaRepository<Endereco, Long> {
}
