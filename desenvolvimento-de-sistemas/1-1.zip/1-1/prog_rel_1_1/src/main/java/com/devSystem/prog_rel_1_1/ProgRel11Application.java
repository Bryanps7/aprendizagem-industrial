package com.devSystem.prog_rel_1_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgRel11Application {

	public static void main(String[] args) {
		SpringApplication.run(ProgRel11Application.class, args);
	}

}
