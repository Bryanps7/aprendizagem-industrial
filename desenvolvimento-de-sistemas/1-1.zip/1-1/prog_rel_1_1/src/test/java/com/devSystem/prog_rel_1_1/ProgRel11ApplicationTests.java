package com.devSystem.prog_rel_1_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgRel11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
