package com.devSystem.um_pra_muitos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UmPraMuitosApplication {

	public static void main(String[] args) {
		SpringApplication.run(UmPraMuitosApplication.class, args);
	}

}
