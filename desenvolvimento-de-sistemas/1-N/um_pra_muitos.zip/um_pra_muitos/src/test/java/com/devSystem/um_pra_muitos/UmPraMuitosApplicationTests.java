package com.devSystem.um_pra_muitos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UmPraMuitosApplicationTests {

	@Test
	void contextLoads() {
	}

}
