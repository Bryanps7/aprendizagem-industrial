package com.devSystem.um_pra_muitos.repository;

import com.devSystem.um_pra_muitos.model.Fabricante;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IFabricanteRepository extends JpaRepository<Fabricante, Long> {
}
