package com.devSystem.um_pra_muitos.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.List;

@Entity
@Table(name = "fabricantes")
public class Fabricante {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codFab;

    @NotBlank(message = "O campo do fabricante é obrigatório!")
    @Size(min=2, message = "O número mínimo de caracter é igual a 2!")
    private String nomeFab;

    @OneToMany(mappedBy = "fabricante",
    cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private List<Produto> produto;

    public Fabricante(){ }

    public Long getCodFab() {
        return codFab;
    }

    public void setCodFab(Long codFab) {
        this.codFab = codFab;
    }

    public String getNomeFab() {
        return nomeFab;
    }

    public void setNomeFab(String nomeFab) {
        this.nomeFab = nomeFab;
    }

    public List<Produto> getProduto() {
        return produto;
    }

    public void setProduto(List<Produto> produto) {
        this.produto = produto;
    }
}
